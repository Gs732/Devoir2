import library


#
# Votre application se lance à partir d'ici (et de nulle part ailleurs)
#
maBiblio = library.Library("book_in.json")

print(maBiblio)  # état initial

# Consigne 2 : Affichage de tous les livres
maBiblio.display_books_all()

# Consigne 3 : Affichage des livres commençant par une lettre donnée
maBiblio.display_books_over_400_pages()
# code à développer suivant les consignes
# par ex. :
# maBiblio.display_books_beginning_by_letter("z")
# maBiblio.dubble_pages_of_books_published_before(1950)
# maBiblio.search_book_between( 1800, 1900 )
# .......

print(maBiblio)  # état final


